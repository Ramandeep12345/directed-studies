//
//  Token.swift
//  FloClu
//
//  Created by Ashish Ashish on 2019-07-29.
//  Copyright © 2019 capstoneProject. All rights reserved.
//

import Foundation

var tokenData = [String]()

var alertUserLatitude: String = ""
var alertUserLongitude: String = ""
var alertUserToken: String = ""


