//
//  PostHeaderView.swift
//  FloClu
//
//  Created by Ashish Ashish on 2019-07-29.
//  Copyright © 2019 capstoneProject. All rights reserved.
//

import Foundation
import UIKit
class PostHeaderView: UICollectionReusableView {
    
   
    @IBOutlet weak var postHeaderLabel: UILabel!
    
}
